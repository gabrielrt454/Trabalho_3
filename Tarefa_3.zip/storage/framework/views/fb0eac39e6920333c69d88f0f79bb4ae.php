<html>
<h2>Adicionar a sua marca à nossa compania</h2>
<form method="POST" action="<?php echo e(route('marca.salvar')); ?>">
    <?php echo csrf_field(); ?>
    <div>
        <label for="nome">Nome de sua marca:</label>
        <input type="text" name="nome_marca" required>
    </div>
 
    <button type="submit" class="btn btn-primary">Salvar</button>
</form>
</html><?php /**PATH C:\Users\fireg\Trabalho_3_10\resources\views/novaMarca.blade.php ENDPATH**/ ?>