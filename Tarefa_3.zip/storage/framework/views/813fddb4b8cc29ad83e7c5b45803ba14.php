<html>
<body>
<div>
    <h1>Lista de Produtos</h1>

    <table>
        <thead>
        <tr>
            <th>ID da Marca</th>
            <th>Nome do produto</th>
            <th>Data de validade</th>
            <th>Valor</th>
        </tr>
        </thead>
        <tbody>
        <tbody>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
            <li><?php echo e($produto->id); ?> - <?php echo e($produto->nome_produto); ?> - <?php echo e($produto->valor); ?> - <?php echo e($produto->data_validade); ?> - <?php echo e($produto->id_marca); ?></li>
</ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</body>
</html>


<?php /**PATH C:\Users\fireg\Trabalho_3_10\resources\views/listarProdutos.blade.php ENDPATH**/ ?>