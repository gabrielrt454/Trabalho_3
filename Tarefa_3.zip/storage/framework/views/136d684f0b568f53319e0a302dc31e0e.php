<!DOCTYPE html>
<html>
    <h2>Editar Marca</h2>
    <form method="POST" action="<?php echo e(route('marca.editar',$marca->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>

        <div>
            <label for="nome">ID:</label>
            <input type="number" name="id" value="<?php echo e($marca->id); ?>" readonly required>
        </div>
        <div>
            <label for="nome_marca">Nome da Marca:</label>
            <input type="text" name="nome_marca" value="<?php echo e($marca->nome_marca); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\fireg\Trabalho_3_10\resources\views/editarMarca.blade.php ENDPATH**/ ?>