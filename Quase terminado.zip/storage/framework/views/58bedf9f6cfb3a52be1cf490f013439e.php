<html>
<body>
<div>
    <h1>Lista de Produtos</h1>

    <table>
        <thead>
        <tr>
            <th>ID da Marca</th>
            <th>Nome da marca</th>
        </tr>
        </thead>
        <tbody>
        <tbody>
        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($marca->nome_marca); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</body>
</html>


<?php /**PATH C:\Users\fireg\Trabalho_3_10\resources\views/listarMarcas.blade.php ENDPATH**/ ?>