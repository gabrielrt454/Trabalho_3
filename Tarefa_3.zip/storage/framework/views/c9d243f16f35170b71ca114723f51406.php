<!DOCTYPE html>
<html>
    <h2>Editar Produto</h2>
    <form method="POST" action="<?php echo e(route('produto.editar',$produto->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>

        <div>
            <label for="nome">ID:</label>
            <input type="number" name="id" value="<?php echo e($produto->id); ?>" readonly required>
        </div>
        <div>
            <label for="nome_produto">Nome do Produto:</label>
            <input type="text" name="nome_produto" value="<?php echo e($produto->nome_produto); ?>" required>
        </div>
        <div>
            <label for="valor">Valor do Produto:</label>
            <input type="number" name="valor" value = "<?php echo e($produto->valor); ?>" required>
        </div>
        <div>
            <label for="data_validade">Data de Validade do Produto:</label>
            <input type="date" name="data_validade" value = "<?php echo e($produto->data_validade); ?>" required>
        </div>
        <div>   
            <label for="id_marca">Id da marca do Produto:</label>
            <input type="number" name="id_marca" value = "<?php echo e($produto->id_marca); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\fireg\Trabalho_3_10\resources\views/editarProduto.blade.php ENDPATH**/ ?>